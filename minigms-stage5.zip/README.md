# Built-in mini GmsCore (YouTube)

Sign in to YouTube without microG. Login screen opens on first launch.

## Install
1. Copy `patches/` and `extensions/` into your revanced-patches checkout (same paths).
2. Build (CI): `./gradlew :patches:buildAndroid`
3. Patch (only this patch; it pulls in "Change package name" + the shared extension automatically):
   `java -jar revanced-cli.jar patch -p patches.rvp --exclusive -e "Built-in mini GmsCore" youtube.apk`

## Stage 1 - core
- Depends on `sharedExtensionPatch` (without it the extension dex is never merged into the APK).
- Hooks: AccountManager (getAccounts*, blockingGetAuthToken, invalidateAuthToken) + GoogleAuthUtil + availability checks.
- Token renewal: cached until 2 min before expiry, 3 tries with backoff, sign-out only after 2 consecutive
  rejections, `audience:` scopes preserved, clearToken forces refresh.
- Login: reads cookie from accounts.google.com, clears web session afterwards, retry on failure, back button,
  works as startActivityForResult (returns authAccount/accountType). Prompts: first launch, then max 1/day, 3 times.
- Build log prints `MiniGms hooks applied: {...}` - check it after patching.

## Stage 2 - notifications
- FCM push needs Google Play Services, so it cannot exist here. Replaced by a persisted job (15 min, Android's
  minimum; Doze can delay it) that reads the real notification inbox (`notification/get_notification_menu`).
- Each new item: title, time, channel/video thumbnail, tap opens the video/channel in the app. Max 5 + grouped summary.
- First poll only records the inbox (no flood). 401/403 -> token renewed and retried once.
- Android 13+ permission requested once. "Sign-in expired" notification if Google revokes the session.

## Stage 3 - auth hardening
- Account token encrypted with an Android Keystore AES-GCM key (old plain value is read and upgraded on next login).
- One refresh per scope at a time (others reuse it); background job renews tokens expiring within 20 min.
- Sign-out only after 3 rejections spanning 20+ min (a Google blip no longer logs you out); `NeedsBrowser` counts as rejection.
- Launcher icon "MiniGms": status, sign in/out, "Renew token now".

## Stage 4 - notifications
- Real FCM push is impossible without Google Play Services, so this stays polling, but tighter: choose 5/15/30/60 min
  in the "MiniGms" launcher screen. <15 min uses a self-re-arming alarm (Doze-friendly, may still be delayed);
  15+ uses the persisted job. Both restored after reboot/app update (receiver).
- Cheap `get_unseen_count` check first; the full inbox is downloaded only when something is unseen.
- Settings: notifications on/off, interval, test notification. Sign out cancels everything.

## Stage 5 - cast (optional, experimental)
- Google Cast needs Play Services, so it can't exist here. Replacement: YouTube's own TV pairing (Lounge API).
- On the TV: YouTube > Settings > Link with TV code. In the "MiniGms" launcher screen tap "Link TV by code".
- Then in the YouTube app: Share > "Cast to TV (MiniGms)" plays that video on the TV (YouTube must be open on the TV).
- Lounge token auto-renews once on expiry. Untested against every TV model: check logcat tag MiniGms if it fails.
- Not included: Chromecast/Google Cast discovery, push via FCM.
