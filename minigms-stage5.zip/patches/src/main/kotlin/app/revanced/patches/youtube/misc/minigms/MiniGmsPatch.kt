package app.revanced.patches.youtube.misc.minigms

import app.revanced.patcher.extensions.InstructionExtensions.addInstruction
import app.revanced.patcher.extensions.InstructionExtensions.replaceInstruction
import app.revanced.patcher.patch.PatchException
import app.revanced.patcher.patch.bytecodePatch
import app.revanced.patcher.patch.resourcePatch
import app.revanced.patches.all.misc.packagename.changePackageNamePatch
import app.revanced.patches.youtube.misc.extension.sharedExtensionPatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.Instruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.instruction.RegisterRangeInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import org.w3c.dom.Document
import org.w3c.dom.Element

private const val EXT_PKG = "Lapp/revanced/extension/youtube/minigms/"
private const val EXT = "${EXT_PKG}MiniGms;"
private const val EXT_DOT = "app.revanced.extension.youtube.minigms"
private val log = java.util.logging.Logger.getLogger("MiniGms")

private fun Document.addPermission(name: String) {
    val l = getElementsByTagName("uses-permission")
    for (i in 0 until l.length) if ((l.item(i) as Element).getAttribute("android:name") == name) return
    documentElement.appendChild(createElement("uses-permission").also { it.setAttribute("android:name", name) })
}

private val miniGmsManifestPatch = resourcePatch {
    execute {
        document("AndroidManifest.xml").use { doc ->
            val app = doc.getElementsByTagName("application").item(0) as Element
            doc.addPermission("android.permission.INTERNET")
            doc.addPermission("android.permission.RECEIVE_BOOT_COMPLETED")
            doc.addPermission("android.permission.POST_NOTIFICATIONS")
            doc.createElement("service").also {
                it.setAttribute("android:name", "$EXT_DOT.MiniGmsNotifyService")
                it.setAttribute("android:permission", "android.permission.BIND_JOB_SERVICE")
                it.setAttribute("android:exported", "false")
                app.appendChild(it)
            }
            doc.createElement("activity").also { a ->
                a.setAttribute("android:name", "$EXT_DOT.MiniGmsCastActivity")
                a.setAttribute("android:label", "Cast to TV (MiniGms)")
                a.setAttribute("android:exported", "true")
                a.setAttribute("android:theme", "@android:style/Theme.Translucent.NoTitleBar")
                a.setAttribute("android:excludeFromRecents", "true")
                a.appendChild(doc.createElement("intent-filter").also { f ->
                    f.appendChild(doc.createElement("action").also { it.setAttribute("android:name", "android.intent.action.SEND") })
                    f.appendChild(doc.createElement("category").also { it.setAttribute("android:name", "android.intent.category.DEFAULT") })
                    f.appendChild(doc.createElement("data").also { it.setAttribute("android:mimeType", "text/plain") })
                })
                app.appendChild(a)
            }
            doc.createElement("receiver").also { r ->
                r.setAttribute("android:name", "$EXT_DOT.MiniGmsReceiver")
                r.setAttribute("android:exported", "false")
                r.appendChild(doc.createElement("intent-filter").also { f ->
                    listOf("android.intent.action.BOOT_COMPLETED", "android.intent.action.MY_PACKAGE_REPLACED").forEach { a ->
                        f.appendChild(doc.createElement("action").also { it.setAttribute("android:name", a) })
                    }
                })
                app.appendChild(r)
            }
            doc.createElement("activity").also {
                it.setAttribute("android:name", "$EXT_DOT.MiniGmsSettingsActivity")
                it.setAttribute("android:exported", "false")
                it.setAttribute("android:theme", "@android:style/Theme.DeviceDefault")
                app.appendChild(it)
            }
            // Launcher icon "MiniGms" -> account screen.
            doc.createElement("activity-alias").also { alias ->
                alias.setAttribute("android:name", "$EXT_DOT.MiniGmsLauncher")
                alias.setAttribute("android:targetActivity", "$EXT_DOT.MiniGmsSettingsActivity")
                alias.setAttribute("android:label", "MiniGms")
                alias.setAttribute("android:exported", "true")
                alias.appendChild(doc.createElement("intent-filter").also { f ->
                    f.appendChild(doc.createElement("action").also { it.setAttribute("android:name", "android.intent.action.MAIN") })
                    f.appendChild(doc.createElement("category").also { it.setAttribute("android:name", "android.intent.category.LAUNCHER") })
                })
                app.appendChild(alias)
            }
            doc.createElement("activity").also {
                it.setAttribute("android:name", "$EXT_DOT.MiniGmsLoginActivity")
                it.setAttribute("android:exported", "false")
                it.setAttribute("android:theme", "@android:style/Theme.DeviceDefault.NoActionBar")
                app.appendChild(it)
            }
        }
    }
}

private data class Hook(val cls: String, val name: String, val desc: String, val newDesc: String)

private const val AM = "Landroid/accounts/AccountManager;"
private const val GAU = "Lcom/google/android/gms/auth/GoogleAuthUtil;"

private val hooks = listOf(
    // Framework APIs: never obfuscated, so these are the reliable hooks.
    Hook(AM, "getAccountsByType", "(Ljava/lang/String;)[Landroid/accounts/Account;",
        "getAccounts(Landroid/accounts/AccountManager;Ljava/lang/String;)[Landroid/accounts/Account;"),
    Hook(AM, "getAccounts", "()[Landroid/accounts/Account;",
        "getAllAccounts(Landroid/accounts/AccountManager;)[Landroid/accounts/Account;"),
    Hook(AM, "blockingGetAuthToken", "(Landroid/accounts/Account;Ljava/lang/String;Z)Ljava/lang/String;",
        "blockingGetAuthToken(Landroid/accounts/AccountManager;Landroid/accounts/Account;Ljava/lang/String;Z)Ljava/lang/String;"),
    Hook(AM, "invalidateAuthToken", "(Ljava/lang/String;Ljava/lang/String;)V",
        "invalidateAuthToken(Landroid/accounts/AccountManager;Ljava/lang/String;Ljava/lang/String;)V"),
    // GMS client library (only matches when the app keeps these names).
    Hook(GAU, "getToken", "(Landroid/content/Context;Landroid/accounts/Account;Ljava/lang/String;)Ljava/lang/String;",
        "getToken(Landroid/content/Context;Landroid/accounts/Account;Ljava/lang/String;)Ljava/lang/String;"),
    Hook(GAU, "getToken", "(Landroid/content/Context;Landroid/accounts/Account;Ljava/lang/String;Landroid/os/Bundle;)Ljava/lang/String;",
        "getToken(Landroid/content/Context;Landroid/accounts/Account;Ljava/lang/String;Landroid/os/Bundle;)Ljava/lang/String;"),
    Hook(GAU, "getToken", "(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;",
        "getTokenByName(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;"),
    Hook(GAU, "clearToken", "(Landroid/content/Context;Ljava/lang/String;)V",
        "clearToken(Landroid/content/Context;Ljava/lang/String;)V"),
    Hook("Lcom/google/android/gms/common/GoogleApiAvailability;", "isGooglePlayServicesAvailable",
        "(Landroid/content/Context;)I", "gmsAvailable(Ljava/lang/Object;Landroid/content/Context;)I"),
    Hook("Lcom/google/android/gms/common/GoogleApiAvailability;", "isGooglePlayServicesAvailable",
        "(Landroid/content/Context;I)I", "gmsAvailableMin(Ljava/lang/Object;Landroid/content/Context;I)I"),
    Hook("Lcom/google/android/gms/common/GooglePlayServicesUtil;", "isGooglePlayServicesAvailable",
        "(Landroid/content/Context;)I", "gmsAvailableStatic(Landroid/content/Context;)I"),
)

private val hookIndex = hooks.associateBy { "${it.cls}->${it.name}${it.desc}" }
private val hookNames = hooks.map { it.name }.toSet()
private val hookClasses = hooks.map { it.cls }.toSet()

private val invokeOpcodes = setOf(
    Opcode.INVOKE_VIRTUAL, Opcode.INVOKE_STATIC, Opcode.INVOKE_VIRTUAL_RANGE, Opcode.INVOKE_STATIC_RANGE,
)

private fun matchHook(ins: Instruction): Hook? {
    if (ins.opcode !in invokeOpcodes) return null
    val ref = (ins as? ReferenceInstruction)?.reference as? MethodReference ?: return null
    if (ref.name !in hookNames || ref.definingClass !in hookClasses) return null // cheap pre-filter
    return hookIndex["${ref.definingClass}->${ref.name}(${ref.parameterTypes.joinToString("")})${ref.returnType}"]
}

private fun smaliFor(ins: Instruction, hook: Hook): String = when (ins) {
    is FiveRegisterInstruction -> {
        val regs = listOf(ins.registerC, ins.registerD, ins.registerE, ins.registerF, ins.registerG)
            .take(ins.registerCount).joinToString(", ") { "v$it" }
        "invoke-static { $regs }, $EXT->${hook.newDesc}"
    }
    is RegisterRangeInstruction -> {
        val end = ins.startRegister + ins.registerCount - 1
        "invoke-static/range { v${ins.startRegister} .. v$end }, $EXT->${hook.newDesc}"
    }
    else -> throw IllegalStateException("Unexpected invoke format")
}

val miniGmsPatch = bytecodePatch(
    name = "Built-in mini GmsCore",
    description = "Sign in to YouTube without microG: login screen, account + OAuth token provider " +
        "with automatic renewal, notifications and optional cast.",
) {
    dependsOn(sharedExtensionPatch, changePackageNamePatch, miniGmsManifestPatch)
    compatibleWith("com.google.android.youtube")

    // If the stock GmsCore support patch is applied anyway, switch its check off.
    finalize {
        classDefs.filter { it.type.endsWith("/GmsCoreSupport;") }.toList().forEach { cls ->
            classDefs.getOrReplaceMutable(cls).methods.filter { it.name == "checkGmsCore" }
                .forEach { it.addInstruction(0, "return-void") }
        }
    }

    execute {
        // Hook the first YouTube activity's onCreate. Class names differ between app versions,
        // so try the known launcher/main activities instead of a single strict fingerprint.
        val ytActivities = classDefs.filter {
            it.type.startsWith("Lcom/google/android/apps/youtube/") && it.type.endsWith("Activity;") &&
                it.methods.any { m -> m.name == "onCreate" }
        }.toList()
        val startSuffixes = listOf("/Shell_HomeActivity;", "/WatchWhileActivity;", "/MainActivity;")
        val startClass = startSuffixes.firstNotNullOfOrNull { suf -> ytActivities.firstOrNull { it.type.endsWith(suf) } }
            ?: throw PatchException(
                "MiniGms: no start activity with onCreate found. Candidates: " +
                    ytActivities.take(20).joinToString { it.type }
            )
        log.info("MiniGms start hook on ${startClass.type}")
        classDefs.getOrReplaceMutable(startClass).methods
            .first { it.name == "onCreate" && it.parameterTypes.size == 1 }
            .addInstruction(0, "invoke-static/range { p0 .. p0 }, $EXT->onAppStart(Landroid/app/Activity;)V")

        val applied = HashMap<String, Int>()
        val targets = classDefs.filter { cd ->
            !cd.type.startsWith(EXT_PKG) &&
                cd.methods.any { m -> m.implementation?.instructions?.any { matchHook(it) != null } == true }
        }.toList() // snapshot before mutating

        targets.forEach { cd ->
            classDefs.getOrReplaceMutable(cd).methods.forEach { method ->
                val impl = method.implementation ?: return@forEach
                impl.instructions.toList().forEachIndexed { i, ins ->
                    val hook = matchHook(ins) ?: return@forEachIndexed
                    method.replaceInstruction(i, smaliFor(ins, hook))
                    applied.merge("${hook.cls.substringAfterLast('/')}${hook.name}", 1, Int::plus)
                }
            }
        }
        log.info("MiniGms hooks applied: $applied")
        if (applied.keys.none { it.startsWith("AccountManager;") })
            log.warning("MiniGms: no AccountManager call sites found - login may not be picked up by the app")
    }
}
