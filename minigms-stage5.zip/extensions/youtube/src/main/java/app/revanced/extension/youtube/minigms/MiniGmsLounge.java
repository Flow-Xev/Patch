package app.revanced.extension.youtube.minigms;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.regex.*;

/** "Cast" without Google Play Services: pair with a TV code, then send videos through YouTube's Lounge API. */
final class MiniGmsLounge {
    private static final String B = "https://www.youtube.com/api/lounge/";

    static final class HttpErr extends IOException {
        final int code;
        HttpErr(int c) { super("HTTP " + c); code = c; }
    }

    /** Pair using the code from TV: Settings > Link with TV code. Returns the TV name. */
    static String pair(Context c, String code) throws IOException {
        String digits = code.replaceAll("\\D", "");
        if (digits.length() < 9) throw new IOException("Enter the TV code (digits only)");
        try {
            JSONObject s = new JSONObject(post(B + "pairing/get_screen", "pairing_code=" + digits)).getJSONObject("screen");
            SharedPreferences sp = MiniGms.p(c);
            String name = s.optString("name", "TV");
            sp.edit().putString("tv_screen", s.getString("screenId")).putString("tv_name", name).apply();
            Vault.save(sp, "tv_token", s.getString("loungeToken"));
            return name;
        } catch (org.json.JSONException e) { throw new IOException("Unexpected reply from YouTube"); }
    }

    static boolean linked(Context c) { return MiniGms.p(c).getString("tv_screen", null) != null; }

    static String name(Context c) { return MiniGms.p(c).getString("tv_name", "TV"); }

    static void forget(Context c) {
        MiniGms.p(c).edit().remove("tv_screen").remove("tv_name").remove("tv_token").apply();
    }

    /** Play a video on the linked TV (the YouTube app must be open on the TV). */
    static void play(Context c, String vid) throws IOException {
        SharedPreferences sp = MiniGms.p(c);
        String screen = sp.getString("tv_screen", null), tok = Vault.load(sp, "tv_token");
        if (screen == null || tok == null) throw new IOException("No TV linked");
        for (int attempt = 0; ; attempt++) {
            try { send(sp, tok, vid); return; }
            catch (HttpErr e) {
                boolean stale = e.code == 400 || e.code == 401 || e.code == 403 || e.code == 410;
                if (attempt > 0 || !stale) throw e;
                tok = refresh(sp, screen); // lounge token expired: renew once and retry
            }
        }
    }

    private static void send(SharedPreferences sp, String tok, String vid) throws IOException {
        String dev = sp.getString("tv_dev", null);
        if (dev == null) { dev = UUID.randomUUID().toString(); sp.edit().putString("tv_dev", dev).apply(); }
        String common = "&VER=8&CVER=1&device=REMOTE_CONTROL&app=youtube-remote&id=" + dev
                + "&loungeIdToken=" + enc(tok);
        String r = post(B + "bc/bind?RID=1&mdx-version=3&name=Phone" + common + "&zx=" + zx(), "count=0");
        String sid = find(r, "\\[\"c\",\"([^\"]+)\""), gs = find(r, "\\[\"S\",\"([^\"]+)\"");
        if (sid == null || gs == null) throw new IOException("TV did not answer. Open YouTube on the TV.");
        post(B + "bc/bind?RID=2&AID=0&SID=" + enc(sid) + "&gsessionid=" + enc(gs) + common + "&zx=" + zx(),
                "count=1&ofs=0&req0__sc=setPlaylist&req0_videoId=" + vid + "&req0_currentTime=0"
                        + "&req0_currentIndex=-1&req0_audioOnly=false&req0_videoIds=" + vid + "&req0_listId=");
    }

    private static String refresh(SharedPreferences sp, String screen) throws IOException {
        try {
            String t = new JSONObject(post(B + "pairing/get_lounge_token_batch", "screen_ids=" + enc(screen)))
                    .getJSONArray("screens").getJSONObject(0).getString("loungeToken");
            Vault.save(sp, "tv_token", t);
            return t;
        } catch (org.json.JSONException e) { throw new IOException("TV link expired. Link the TV again."); }
    }

    private static String find(String s, String re) {
        Matcher m = Pattern.compile(re).matcher(s);
        return m.find() ? m.group(1) : null;
    }

    private static String enc(String s) throws UnsupportedEncodingException { return URLEncoder.encode(s, "UTF-8"); }

    private static String zx() { return Long.toString(Math.abs(new Random().nextLong()), 36); }

    private static String post(String url, String body) throws IOException {
        HttpURLConnection h = (HttpURLConnection) new URL(url).openConnection();
        h.setConnectTimeout(15000);
        h.setReadTimeout(20000);
        h.setRequestMethod("POST");
        h.setDoOutput(true);
        h.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
        h.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/124.0 Mobile Safari/537.36");
        try (OutputStream o = h.getOutputStream()) { o.write(body.getBytes("UTF-8")); }
        int code = h.getResponseCode();
        if (code >= 400) throw new HttpErr(code);
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(h.getInputStream(), "UTF-8"))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line).append('\n');
        }
        return sb.toString();
    }
}
