package app.revanced.extension.youtube.minigms;

import android.app.*;
import android.app.job.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.util.Log;

import org.json.*;

import java.io.*;
import java.net.*;
import java.util.*;

/**
 * Replacement for FCM push (needs Google Play Services, so impossible here): a persisted background job,
 * every ~15 min (Android's minimum), reads the account's real YouTube notification inbox and shows each
 * new item with title, thumbnail and a tap-through to the video/channel.
 */
public class MiniGmsNotifyService extends JobService {
    private static final int JOB_ID = 7311;
    static final String CHANNEL = "minigms_notifications", GROUP = "minigms_group";
    private static final String SCOPE = "oauth2:https://www.googleapis.com/auth/youtube";
    private static final String API = "https://youtubei.googleapis.com/youtubei/v1/";
    private static final int MAX_SHOWN = 5, MAX_SEEN = 200;

    private static final int JOB_NOW = 7312, ALARM_ID = 7313;

    /** Idempotent: safe to call on every app start. Persisted periodic job + (if interval < 15 min) an alarm chain. */
    public static void schedule(Context c) {
        try {
            SharedPreferences sp = MiniGms.p(c);
            if (!sp.getBoolean("notif_on", true)) { cancel(c); return; }
            int min = sp.getInt("notif_min", 15);
            long period = Math.max(15, min) * 60_000L;
            JobScheduler js = (JobScheduler) c.getSystemService(Context.JOB_SCHEDULER_SERVICE);
            boolean ok = false;
            for (JobInfo j : js.getAllPendingJobs())
                if (j.getId() == JOB_ID && j.getIntervalMillis() == period) ok = true;
            if (!ok) js.schedule(new JobInfo.Builder(JOB_ID, new ComponentName(c, MiniGmsNotifyService.class))
                    .setPeriodic(period)
                    .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                    .setPersisted(true)
                    .build());
            if (min < 15) arm(c, min); else disarm(c);
        } catch (Exception e) { Log.w(MiniGms.TAG, "schedule failed", e); }
    }

    /** One immediate poll (alarm tick). */
    static void pollNow(Context c) {
        try {
            ((JobScheduler) c.getSystemService(Context.JOB_SCHEDULER_SERVICE)).schedule(
                    new JobInfo.Builder(JOB_NOW, new ComponentName(c, MiniGmsNotifyService.class))
                            .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                            .setOverrideDeadline(0).build());
        } catch (Exception e) { Log.w(MiniGms.TAG, "pollNow failed", e); }
    }

    static void cancel(Context c) {
        try {
            JobScheduler js = (JobScheduler) c.getSystemService(Context.JOB_SCHEDULER_SERVICE);
            js.cancel(JOB_ID);
            js.cancel(JOB_NOW);
            disarm(c);
        } catch (Exception ignored) {}
    }

    private static PendingIntent alarmIntent(Context c) {
        return PendingIntent.getBroadcast(c, ALARM_ID,
                new Intent(c, MiniGmsReceiver.class).setAction(MiniGmsReceiver.TICK),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private static void arm(Context c, int min) {
        ((AlarmManager) c.getSystemService(Context.ALARM_SERVICE)).setAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + min * 60_000L, alarmIntent(c));
    }

    private static void disarm(Context c) {
        ((AlarmManager) c.getSystemService(Context.ALARM_SERVICE)).cancel(alarmIntent(c));
    }

    /** Settings "Test notification". */
    static void test(Context c) {
        Item it = new Item();
        it.id = "test" + System.currentTimeMillis();
        it.title = "Test notification: it works";
        it.text = "now";
        show(c, Collections.singletonList(it));
    }

    @Override public boolean onStartJob(JobParameters params) {
        new Thread(() -> {
            boolean retry = false;
            if (!MiniGms.p(getApplicationContext()).getBoolean("notif_on", true)) { jobFinished(params, false); return; }
            try { MiniGms.renewExpiring(getApplicationContext(), 20 * 60_000L); check(getApplicationContext()); }
            catch (IOException e) { retry = true; Log.w(MiniGms.TAG, "poll: " + e.getMessage()); }
            catch (Throwable t) { Log.w(MiniGms.TAG, "poll failed", t); }
            jobFinished(params, retry);
        }).start();
        return true;
    }

    @Override public boolean onStopJob(JobParameters params) { return true; }

    // ---- polling ------------------------------------------------------------------------

    private static final class Item {
        String id, title, text, url, thumb; boolean read;
    }

    private static void check(Context c) throws IOException {
        String email = MiniGms.getEmail(c);
        if (email == null) return;
        String prev = MiniGms.p(c).getString("seen", null);
        if (prev != null && unseenZero(c, email)) return; // cheap check first, skip the big inbox download
        List<Item> items = parse(request(c, email, "notification/get_notification_menu",
                "\"notificationsMenuRequestType\":\"NOTIFICATIONS_MENU_REQUEST_TYPE_INBOX\""));
        SharedPreferences sp = MiniGms.p(c);
        boolean first = prev == null; // first run only records the inbox, never floods
        LinkedHashSet<String> seen = new LinkedHashSet<>();
        if (prev != null && !prev.isEmpty()) seen.addAll(Arrays.asList(prev.split("\n")));

        List<Item> fresh = new ArrayList<>();
        for (Item it : items) if (!it.read && !seen.contains(it.id)) fresh.add(it);
        for (Item it : items) seen.add(it.id);
        while (seen.size() > MAX_SEEN) { Iterator<String> i = seen.iterator(); i.next(); i.remove(); }
        sp.edit().putString("seen", String.join("\n", seen)).apply();

        if (!first && !fresh.isEmpty()) show(c, fresh);
    }

    private static boolean unseenZero(Context c, String email) {
        try {
            java.util.regex.Matcher m = java.util.regex.Pattern.compile("\"unseenCount\"\\s*:\\s*(\\d+)")
                    .matcher(request(c, email, "notification/get_unseen_count", ""));
            return m.find() && Integer.parseInt(m.group(1)) == 0;
        } catch (IOException e) { return false; } // unknown -> do the full fetch
    }

    private static String request(Context c, String email, String path, String extra) throws IOException {
        String ver = "19.09.37";
        try { ver = c.getPackageManager().getPackageInfo(c.getPackageName(), 0).versionName; }
        catch (PackageManager.NameNotFoundException ignored) {}
        Locale l = Locale.getDefault();
        String body = "{\"context\":{\"client\":{\"clientName\":\"ANDROID\",\"clientVersion\":\"" + ver
                + "\",\"androidSdkVersion\":" + Build.VERSION.SDK_INT + ",\"hl\":\"" + l.getLanguage()
                + "\",\"gl\":\"" + (l.getCountry().isEmpty() ? "US" : l.getCountry()) + "\"}}"
                + (extra.isEmpty() ? "" : "," + extra) + "}";
        for (int attempt = 0; attempt < 2; attempt++) {
            String token = MiniGms.getTokenByName(c, email, SCOPE);
            HttpURLConnection h = (HttpURLConnection) new URL(API + path).openConnection();
            h.setConnectTimeout(15000);
            h.setReadTimeout(15000);
            h.setRequestMethod("POST");
            h.setDoOutput(true);
            h.setRequestProperty("Content-Type", "application/json");
            h.setRequestProperty("Authorization", "Bearer " + token);
            h.setRequestProperty("User-Agent", "com.google.android.youtube/" + ver
                    + " (Linux; U; Android " + Build.VERSION.RELEASE + ") gzip");
            try (OutputStream o = h.getOutputStream()) { o.write(body.getBytes("UTF-8")); }
            int code = h.getResponseCode();
            if (code == 401 || code == 403) { MiniGms.clearToken(c, token); continue; } // renew + retry once
            if (code >= 400) throw new IOException("HTTP " + code);
            StringBuilder sb = new StringBuilder();
            try (BufferedReader br = new BufferedReader(new InputStreamReader(h.getInputStream(), "UTF-8"))) {
                String line;
                while ((line = br.readLine()) != null) sb.append(line);
            }
            return sb.toString();
        }
        throw new IOException("token rejected");
    }

    private static List<Item> parse(String json) {
        List<Item> out = new ArrayList<>();
        try {
            List<JSONObject> rs = new ArrayList<>();
            collect(new JSONObject(json), rs);
            for (JSONObject r : rs) {
                Item it = new Item();
                it.title = text(r.optJSONObject("shortMessage"));
                it.text = text(r.optJSONObject("sentTimeText"));
                it.read = r.optBoolean("read", false);
                it.id = r.optString("notificationId", "");
                if (it.id.isEmpty()) it.id = Integer.toHexString((it.title + it.text).hashCode());
                it.thumb = lastThumb(r.optJSONObject("videoThumbnail"));
                if (it.thumb == null) it.thumb = lastThumb(r.optJSONObject("thumbnail"));
                JSONObject nav = r.optJSONObject("navigationEndpoint");
                if (nav != null) {
                    JSONObject w = nav.optJSONObject("watchEndpoint");
                    if (w != null && w.has("videoId")) it.url = "https://www.youtube.com/watch?v=" + w.optString("videoId");
                    else {
                        JSONObject cm = nav.optJSONObject("commandMetadata");
                        JSONObject wm = cm == null ? null : cm.optJSONObject("webCommandMetadata");
                        String u = wm == null ? null : wm.optString("url", null);
                        if (u != null) it.url = u.startsWith("/") ? "https://www.youtube.com" + u : u;
                    }
                }
                if (!it.title.isEmpty()) out.add(it);
            }
        } catch (JSONException e) { Log.w(MiniGms.TAG, "parse failed", e); }
        return out;
    }

    private static void collect(Object n, List<JSONObject> out) {
        if (n instanceof JSONObject) {
            JSONObject o = (JSONObject) n;
            Iterator<String> k = o.keys();
            while (k.hasNext()) {
                String key = k.next();
                Object v = o.opt(key);
                if ("notificationRenderer".equals(key) && v instanceof JSONObject) out.add((JSONObject) v);
                else collect(v, out);
            }
        } else if (n instanceof JSONArray) {
            JSONArray a = (JSONArray) n;
            for (int i = 0; i < a.length(); i++) collect(a.opt(i), out);
        }
    }

    private static String text(JSONObject o) {
        if (o == null) return "";
        String s = o.optString("simpleText", null);
        if (s != null) return s;
        JSONArray runs = o.optJSONArray("runs");
        StringBuilder sb = new StringBuilder();
        if (runs != null) for (int i = 0; i < runs.length(); i++) {
            JSONObject r = runs.optJSONObject(i);
            if (r != null) sb.append(r.optString("text"));
        }
        return sb.toString();
    }

    private static String lastThumb(JSONObject o) {
        JSONArray a = o == null ? null : o.optJSONArray("thumbnails");
        JSONObject t = a == null || a.length() == 0 ? null : a.optJSONObject(a.length() - 1);
        String u = t == null ? null : t.optString("url", null);
        return u != null && u.startsWith("//") ? "https:" + u : u;
    }

    // ---- display ------------------------------------------------------------------------

    private static void channel(Context c, NotificationManager nm) {
        if (Build.VERSION.SDK_INT >= 26)
            nm.createNotificationChannel(new NotificationChannel(
                    CHANNEL, "YouTube notifications", NotificationManager.IMPORTANCE_DEFAULT));
    }

    private static Notification.Builder builder(Context c) {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(c, CHANNEL) : new Notification.Builder(c);
        try { b.setSmallIcon(Icon.createWithResource(c, c.getApplicationInfo().icon)); }
        catch (Throwable t) { b.setSmallIcon(android.R.drawable.stat_notify_chat); }
        return b.setAutoCancel(true).setGroup(GROUP);
    }

    private static PendingIntent open(Context c, String url, int code) {
        Intent i = url == null ? null : new Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage(c.getPackageName());
        if (i == null || i.resolveActivity(c.getPackageManager()) == null)
            i = c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
        if (i == null) i = new Intent();
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        return PendingIntent.getActivity(c, code, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private static void show(Context c, List<Item> fresh) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        channel(c, nm);
        int n = Math.min(fresh.size(), MAX_SHOWN);
        for (int k = 0; k < n; k++) {
            Item it = fresh.get(k);
            Notification.Builder b = builder(c).setContentTitle("YouTube").setContentText(it.title)
                    .setStyle(new Notification.BigTextStyle().bigText(it.title))
                    .setContentIntent(open(c, it.url, it.id.hashCode()));
            if (it.text != null && !it.text.isEmpty()) b.setSubText(it.text);
            Bitmap bm = bitmap(it.thumb);
            if (bm != null) b.setLargeIcon(bm);
            nm.notify("yt", it.id.hashCode(), b.build());
        }
        if (fresh.size() > 1) {
            nm.notify("yt", 0, builder(c).setContentTitle("YouTube")
                    .setContentText(fresh.size() + " new notifications").setGroupSummary(true)
                    .setContentIntent(open(c, null, 1)).build());
        }
    }

    private static Bitmap bitmap(String url) {
        if (url == null) return null;
        try {
            HttpURLConnection h = (HttpURLConnection) new URL(url).openConnection();
            h.setConnectTimeout(8000);
            h.setReadTimeout(8000);
            try (InputStream in = h.getInputStream()) { return BitmapFactory.decodeStream(in); }
        } catch (Exception e) { return null; }
    }

    /** Tell the user the account needs to be signed in again (token revoked). */
    static void notifyRelogin(Context c) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        channel(c, nm);
        Intent i = new Intent(c, MiniGmsLoginActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        nm.notify("yt", 1, builder(c).setContentTitle("YouTube").setContentText("Sign-in expired. Tap to sign in again.")
                .setContentIntent(PendingIntent.getActivity(c, 2, i,
                        PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT)).build());
    }
}
