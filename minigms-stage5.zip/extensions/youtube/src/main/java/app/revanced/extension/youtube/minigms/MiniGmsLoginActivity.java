package app.revanced.extension.youtube.minigms;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.webkit.*;
import android.widget.Toast;

/** Opens Google's embedded setup page, grabs the oauth_token cookie, finishes. */
public class MiniGmsLoginActivity extends Activity {
    private static final String URL = "https://accounts.google.com/EmbeddedSetup";
    private static final String HOST = "https://accounts.google.com";
    private boolean done;
    private WebView web;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.removeAllCookies(null);

        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setUserAgentString("Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 "
                + "(KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36");
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView v, String url) { check(cm); }
        });
        web.loadUrl(URL);
    }

    private void check(CookieManager cm) {
        if (done) return;
        String tok = cookie(cm.getCookie(HOST), "oauth_token");
        if (tok == null) return;
        done = true;
        new Thread(() -> {
            try {
                String email = MiniGms.completeLogin(getApplicationContext(), tok);
                runOnUiThread(() -> success(cm, email));
            } catch (Exception e) {
                CrashLog.record("login: token exchange failed", e);
                runOnUiThread(() -> {
                    done = false;
                    cm.removeAllCookies(null);
                    Toast.makeText(this, "Sign-in failed: " + e.getClass().getSimpleName() + " - see MiniGms screen", Toast.LENGTH_LONG).show();
                    web.loadUrl(URL); // let the user try again
                });
            }
        }).start();
    }

    private void success(CookieManager cm, String email) {
        cm.removeAllCookies(null); // don't leave the web session behind
        Toast.makeText(this, "Signed in", Toast.LENGTH_SHORT).show();
        if (getCallingActivity() != null) { // started for a result (account picker)
            setResult(RESULT_OK, new Intent()
                    .putExtra("authAccount", email).putExtra("accountType", MiniGms.GOOGLE));
        } else {
            Intent i = getPackageManager().getLaunchIntentForPackage(getPackageName());
            if (i != null) { // restart so the app re-reads accounts
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(i);
            }
        }
        finish();
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }

    private static String cookie(String all, String name) {
        if (all == null) return null;
        for (String part : all.split(";\\s*"))
            if (part.startsWith(name + "=")) return part.substring(name.length() + 1);
        return null;
    }
}
