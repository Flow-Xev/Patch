package app.revanced.extension.youtube.minigms;

import android.content.Context;
import android.util.Log;

import java.io.PrintWriter;
import java.io.StringWriter;

/** Keeps the last uncaught exception so it can be read on the "MiniGms" screen (no PC / logcat needed). */
final class CrashLog {
    private static final String FILE = "minigms_crash", KEY = "trace";
    private static boolean installed;

    static synchronized void install() {
        if (installed) return;
        installed = true;
        final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((t, e) -> {
            record("uncaught exception on thread " + t.getName(), e);
            if (prev != null) prev.uncaughtException(t, e);
        });
    }

    /** Saves the stack trace; never throws. */
    static void record(String where, Throwable e) {
        try {
            Log.e(MiniGms.TAG, where, e);
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            String s = new java.util.Date() + "\n" + where + "\n" + sw;
            if (s.length() > 9000) s = s.substring(0, 9000);
            prefs(MiniGms.appContext()).edit().putString(KEY, s).commit();
        } catch (Throwable ignored) { }
    }

    static String last(Context c) { return prefs(c).getString(KEY, null); }

    static void clear(Context c) { prefs(c).edit().remove(KEY).apply(); }

    private static android.content.SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }
}
