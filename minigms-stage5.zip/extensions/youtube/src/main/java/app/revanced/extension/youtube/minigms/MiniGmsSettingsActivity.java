package app.revanced.extension.youtube.minigms;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

import java.io.IOException;

/** Minimal account screen (launcher icon "MiniGms"): status, sign in/out, manual token renewal. */
public class MiniGmsSettingsActivity extends Activity {
    private LinearLayout box;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView sv = new ScrollView(this);
        box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (20 * getResources().getDisplayMetrics().density);
        box.setPadding(pad, pad * 2, pad, pad);
        sv.addView(box);
        setContentView(sv);
    }

    @Override protected void onResume() { super.onResume(); render(); }

    private void render() {
        box.removeAllViews();
        boolean in = MiniGms.isSignedIn(this);
        TextView t = new TextView(this);
        t.setTextSize(18);
        t.setText(in ? "Signed in as " + MiniGms.getEmail(this) : "Not signed in");
        box.addView(t);
        button(in ? "Sign in again" : "Sign in", v -> startActivity(new Intent(this, MiniGmsLoginActivity.class)));
        if (MiniGmsLounge.linked(this)) {
            button("Linked TV: " + MiniGmsLounge.name(this) + " (tap to forget)", v -> { MiniGmsLounge.forget(this); render(); });
        } else {
            button("Link TV by code (cast, optional)", v -> MiniGmsCastActivity.askCode(this, this::render, () -> {}));
        }
        if (!in) return;
        button("Renew token now", v -> new Thread(() -> {
            String m;
            try { MiniGms.renew(this); m = "Token renewed"; } catch (IOException e) { m = e.getMessage(); }
            String msg = m;
            runOnUiThread(() -> Toast.makeText(this, msg, Toast.LENGTH_LONG).show());
        }).start());
        SharedPreferences sp = MiniGms.p(this);
        boolean on = sp.getBoolean("notif_on", true);
        int min = sp.getInt("notif_min", 15);
        button("Notifications: " + (on ? "ON" : "OFF"), v -> {
            sp.edit().putBoolean("notif_on", !on).apply();
            MiniGmsNotifyService.schedule(this);
            render();
        });
        button("Check every " + min + " min (tap to change)", v -> {
            sp.edit().putInt("notif_min", min == 5 ? 15 : min == 15 ? 30 : min == 30 ? 60 : 5).apply();
            MiniGmsNotifyService.schedule(this);
            render();
        });
        button("Test notification", v -> MiniGmsNotifyService.test(this));
        button("Sign out", v -> { MiniGms.signOut(this); render(); });
    }

    private void button(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setOnClickListener(l);
        box.addView(b);
    }
}
