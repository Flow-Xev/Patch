package app.revanced.extension.youtube.minigms;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Boot / app-update: restore the poll schedule. TICK (alarm): poll now and re-arm. */
public class MiniGmsReceiver extends BroadcastReceiver {
    static final String TICK = "app.revanced.extension.youtube.minigms.TICK";

    @Override public void onReceive(Context c, Intent i) {
        if (!MiniGms.isSignedIn(c)) return;
        MiniGmsNotifyService.schedule(c); // re-arms the alarm chain
        if (TICK.equals(i.getAction())) MiniGmsNotifyService.pollNow(c);
    }
}
