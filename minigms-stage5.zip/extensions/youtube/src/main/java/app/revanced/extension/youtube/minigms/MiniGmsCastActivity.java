package app.revanced.extension.youtube.minigms;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.widget.EditText;
import android.widget.Toast;

import java.io.IOException;
import java.util.regex.*;

/** Share a YouTube link to "Cast to TV (MiniGms)" -> plays on the linked TV. Optional: unused unless you pick it. */
public class MiniGmsCastActivity extends Activity {
    private static final Pattern ID = Pattern.compile("(?:v=|youtu\\.be/|shorts/|live/|embed/)([A-Za-z0-9_-]{11})");

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        Intent i = getIntent();
        String src = i.getStringExtra(Intent.EXTRA_TEXT);
        if (src == null && i.getData() != null) src = i.getData().toString();
        Matcher m = src == null ? null : ID.matcher(src);
        if (m == null || !m.find()) { toast("No YouTube video found"); finish(); return; }
        String vid = m.group(1);
        if (MiniGmsLounge.linked(this)) play(vid);
        else askCode(this, () -> play(vid), this::finish);
    }

    private void play(String vid) {
        new Thread(() -> {
            String msg;
            try { MiniGmsLounge.play(getApplicationContext(), vid); msg = "Sent to " + MiniGmsLounge.name(this); }
            catch (IOException e) { msg = String.valueOf(e.getMessage()); }
            String m = msg;
            runOnUiThread(() -> { toast(m); finish(); });
        }).start();
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    /** Ask for the TV code (TV: YouTube > Settings > Link with TV code) and pair. */
    static void askCode(Activity a, Runnable ok, Runnable cancel) {
        EditText e = new EditText(a);
        e.setInputType(InputType.TYPE_CLASS_NUMBER);
        e.setHint("TV code");
        new AlertDialog.Builder(a).setTitle("Link TV").setMessage("TV: YouTube > Settings > Link with TV code")
                .setView(e)
                .setPositiveButton("Link", (d, w) -> new Thread(() -> {
                    String err = null;
                    try { MiniGmsLounge.pair(a.getApplicationContext(), e.getText().toString()); }
                    catch (IOException x) { err = String.valueOf(x.getMessage()); }
                    String m = err;
                    a.runOnUiThread(() -> {
                        if (m == null) ok.run();
                        else { Toast.makeText(a, m, Toast.LENGTH_LONG).show(); cancel.run(); }
                    });
                }).start())
                .setNegativeButton("Cancel", (d, w) -> cancel.run())
                .setOnCancelListener(d -> cancel.run())
                .show();
    }
}
