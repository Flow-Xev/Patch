package app.revanced.extension.youtube.minigms;

import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.security.KeyStore;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Secret storage: AES-GCM with a non-exportable Android Keystore key. Falls back to plain text if Keystore fails. */
final class Vault {
    private static final String ALIAS = "minigms", PFX = "v1:";

    static String load(SharedPreferences sp, String k) {
        String s = sp.getString(k, null);
        if (s == null || !s.startsWith(PFX)) return s; // null or legacy plain value
        try {
            byte[] raw = Base64.decode(s.substring(PFX.length()), Base64.NO_WRAP);
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, raw, 0, 12));
            return new String(c.doFinal(raw, 12, raw.length - 12), "UTF-8");
        } catch (Exception e) { return null; } // key lost -> treated as signed out
    }

    static void save(SharedPreferences sp, String k, String v) {
        try {
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.ENCRYPT_MODE, key());
            byte[] iv = c.getIV(), ct = c.doFinal(v.getBytes("UTF-8")), out = new byte[iv.length + ct.length];
            System.arraycopy(iv, 0, out, 0, iv.length);
            System.arraycopy(ct, 0, out, iv.length, ct.length);
            sp.edit().putString(k, PFX + Base64.encodeToString(out, Base64.NO_WRAP)).apply();
        } catch (Exception e) { sp.edit().putString(k, v).apply(); }
    }

    private static SecretKey key() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (ks.containsAlias(ALIAS)) return (SecretKey) ks.getKey(ALIAS, null);
        KeyGenerator g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        g.init(new KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256).build());
        return g.generateKey();
    }
}
