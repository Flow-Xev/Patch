package app.revanced.extension.youtube.minigms;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;

import java.io.*;
import java.net.*;
import java.util.*;

/** Tiny stand-in for the parts of microG that YouTube needs: account + OAuth tokens. */
public final class MiniGms {
    static final String TAG = "MiniGms";
    static final String GOOGLE = "com.google";
    private static final String AUTH_URL = "https://android.googleapis.com/auth";
    private static final String GMS_PKG = "com.google.android.gms";
    private static final String GMS_SIG = "38918a453d07199354f8b19af05ec6562ced5788";
    private static final String YT_PKG = "com.google.android.youtube";
    private static final String YT_SIG = "24bb24c05e47e0aefa68a58a766179d9b613a600";
    private static final int MAX_LOGIN_PROMPTS = 3;
    private static final long DAY = 24L * 3600 * 1000, SKEW = 2L * 60 * 1000;
    private static final Set<String> PERMANENT = new HashSet<>(Arrays.asList(
            "BadAuthentication", "AccountDeleted", "AccountDisabled", "InvalidSecondFactor", "NeedsBrowser"));
    static final String YT_SCOPE = "oauth2:https://www.googleapis.com/auth/youtube";
    private static final java.util.concurrent.ConcurrentHashMap<String, Object> LOCKS =
            new java.util.concurrent.ConcurrentHashMap<>();

    /** Token request failed; permanent = Google says the stored credential is no longer valid. */
    static final class AuthError extends IOException {
        final boolean permanent;
        AuthError(String m, boolean permanent) { super("MiniGms: " + m); this.permanent = permanent; }
    }

    static { CrashLog.install(); }

    static SharedPreferences p(Context c) { return c.getSharedPreferences("minigms", Context.MODE_PRIVATE); }

    static Context appContext() {
        try {
            return (Context) Class.forName("android.app.ActivityThread")
                    .getMethod("currentApplication").invoke(null);
        } catch (Exception e) { throw new IllegalStateException(e); }
    }

    // ---- hooks called from patched app code ----------------------------------------------

    /** Main activity onCreate: ask to sign in (first launch, then at most once a day, 3 times). */
    public static void onAppStart(Activity a) {
        try {
            publishShortcut(a);
            if (isSignedIn(a)) { MiniGmsNotifyService.schedule(a); askNotifPermission(a); return; }
            SharedPreferences sp = p(a);
            int n = sp.getInt("asks", 0);
            long now = System.currentTimeMillis();
            if (n >= MAX_LOGIN_PROMPTS || (n > 0 && now - sp.getLong("ask_at", 0) < DAY)) return;
            sp.edit().putInt("asks", n + 1).putLong("ask_at", now).apply();
            a.startActivity(new Intent(a, MiniGmsLoginActivity.class));
        } catch (Throwable t) { // never let the sign-in helper take the app down
            CrashLog.record("onAppStart", t);
        }
    }

    /** Adds "MiniGms" to the long-press menu of the YouTube icon (no separate launcher icon). */
    private static void publishShortcut(Activity a) {
        try {
            if (android.os.Build.VERSION.SDK_INT < 25 || p(a).getBoolean("shortcut_v1", false)) return;
            android.content.pm.ShortcutManager sm = a.getSystemService(android.content.pm.ShortcutManager.class);
            if (sm == null) return;
            Intent i = new Intent(Intent.ACTION_VIEW)
                    .setClassName(a.getPackageName(), MiniGmsSettingsActivity.class.getName());
            android.content.pm.ShortcutInfo si = new android.content.pm.ShortcutInfo.Builder(a, "minigms")
                    .setShortLabel("MiniGms").setLongLabel("MiniGms account")
                    .setIcon(android.graphics.drawable.Icon.createWithResource(a, android.R.drawable.ic_menu_manage))
                    .setIntent(i).build();
            if (android.os.Build.VERSION.SDK_INT >= 30) sm.pushDynamicShortcut(si);
            else sm.addDynamicShortcuts(Collections.singletonList(si));
            p(a).edit().putBoolean("shortcut_v1", true).apply();
        } catch (Throwable t) { Log.w(TAG, "shortcut failed", t); }
    }

    /** Android 13+: ask for the notification permission once. */
    private static void askNotifPermission(Activity a) {
        String perm = "android.permission.POST_NOTIFICATIONS";
        SharedPreferences sp = p(a);
        if (android.os.Build.VERSION.SDK_INT < 33 || sp.getBoolean("notif_asked", false)
                || a.checkSelfPermission(perm) == android.content.pm.PackageManager.PERMISSION_GRANTED) return;
        sp.edit().putBoolean("notif_asked", true).apply();
        a.requestPermissions(new String[]{perm}, 7311);
    }

    // ---- Toast hooks: hide Google's "Blocked unpatched use of SSL stack." message ------------------

    private static final java.util.Map<android.widget.Toast, Boolean> HIDDEN =
            java.util.Collections.synchronizedMap(new java.util.WeakHashMap<>());

    /** Google's SSL notice (or an empty text left by the build-time source patch). */
    private static boolean isSslToast(CharSequence s) {
        if (s == null) return false;
        String t = s.toString();
        if (t.isEmpty()) return true;
        return t.contains("unpatched use of SSL") || t.contains("SSL stack");
    }

    private static android.widget.Toast mark(android.widget.Toast t, CharSequence s) {
        if (isSslToast(s)) {
            CrashLog.note("SSL toast suppressed; it was created here:", new Throwable());
            HIDDEN.put(t, Boolean.TRUE);
        }
        return t;
    }

    public static android.widget.Toast makeText(Context c, CharSequence s, int duration) {
        return mark(android.widget.Toast.makeText(c, s, duration), s);
    }

    public static android.widget.Toast makeText(Context c, int resId, int duration) {
        return mark(android.widget.Toast.makeText(c, resId, duration), c.getResources().getText(resId));
    }

    public static void setText(android.widget.Toast t, CharSequence s) {
        if (isSslToast(s)) mark(t, s); else HIDDEN.remove(t);
        t.setText(s);
    }

    public static void setText(android.widget.Toast t, int resId) {
        setText(t, appContext().getResources().getText(resId));
    }

    /** Every Toast.show() in the app goes through here: hidden ones are simply never shown. */
    public static void show(android.widget.Toast t) {
        if (t == null || HIDDEN.containsKey(t)) return;
        t.show();
    }

    public static int gmsAvailable(Object api, Context c) { return 0; }
    public static int gmsAvailableStatic(Context c) { return 0; }
    public static int gmsAvailableMin(Object api, Context c, int min) { return 0; }

    public static Account[] getAccounts(AccountManager am, String type) {
        if (!GOOGLE.equals(type)) return am.getAccountsByType(type);
        String email = getEmail(appContext());
        return email == null ? new Account[0] : new Account[]{new Account(email, GOOGLE)};
    }

    public static Account[] getAllAccounts(AccountManager am) {
        List<Account> l = new ArrayList<>();
        try { l.addAll(Arrays.asList(am.getAccounts())); } catch (Throwable ignored) {}
        String email = getEmail(appContext());
        if (email != null) {
            Account a = new Account(email, GOOGLE);
            if (!l.contains(a)) l.add(0, a);
        }
        return l.toArray(new Account[0]);
    }

    public static String blockingGetAuthToken(AccountManager am, Account a, String type, boolean notify)
            throws IOException {
        return getTokenByName(appContext(), a.name, type);
    }

    public static void invalidateAuthToken(AccountManager am, String type, String token) {
        if (GOOGLE.equals(type)) clearToken(appContext(), token);
        else am.invalidateAuthToken(type, token);
    }

    public static String getToken(Context c, Account acc, String scope) throws IOException {
        return getTokenByName(c, acc.name, scope);
    }

    public static String getToken(Context c, Account acc, String scope, Bundle extras) throws IOException {
        return getTokenByName(c, acc.name, scope);
    }

    /** Cached access token, renewed ~2 min before expiry; retries transient failures. */
    public static String getTokenByName(Context c, String email, String scope) throws IOException {
        return token(c, email, scope, false);
    }

    /** Force a new access token for the YouTube scope (used by settings + background job). */
    static void renew(Context c) throws IOException {
        String email = getEmail(c);
        if (email == null) throw new IOException("MiniGms: not signed in");
        token(c, email, YT_SCOPE, true);
    }

    /** Refresh every cached token that expires within {@code window} ms, so the app never meets an expired one. */
    static void renewExpiring(Context c, long window) {
        SharedPreferences sp = p(c);
        String email = getEmail(c);
        if (email == null) return;
        for (String k : new ArrayList<>(sp.getAll().keySet())) {
            if (!k.startsWith("tok:") || k.endsWith(":exp")) continue;
            if (sp.getLong(k + ":exp", 0) - System.currentTimeMillis() < window) {
                try { token(c, email, k.substring(4), true); } catch (IOException ignored) {}
            }
        }
    }

    private static String token(Context c, String email, String scope, boolean force) throws IOException {
        SharedPreferences sp = p(c);
        String aas = Vault.load(sp, "aas");
        if (aas == null) throw new IOException("MiniGms: not signed in");
        if (!scope.startsWith("oauth2:") && !scope.startsWith("audience:")) scope = "oauth2:" + scope;
        String key = "tok:" + scope;
        Object lock = LOCKS.computeIfAbsent(key, k -> new Object()); // one refresh per scope, others reuse it
        synchronized (lock) {
            String cached = sp.getString(key, null);
            if (!force && cached != null && System.currentTimeMillis() < sp.getLong(key + ":exp", 0) - SKEW)
                return cached;
            IOException last = null;
            for (int i = 0; i < 3; i++) {
                try {
                    return fetchToken(c, sp, aas, email, scope, key);
                } catch (AuthError e) {
                    if (e.permanent) { rejected(c, sp); throw e; }
                    last = e;
                } catch (IOException e) {
                    last = e;
                }
                if (i < 2) try { Thread.sleep(1000L * (i + 1)); } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
            throw last != null ? last : new IOException("MiniGms: interrupted");
        }
    }

    /** Google rejected the stored credential. Sign out only if it keeps happening for 20+ min (not a blip). */
    private static void rejected(Context c, SharedPreferences sp) {
        long now = System.currentTimeMillis(), since = sp.getLong("bad_at", 0);
        int bad = sp.getInt("bad", 0) + 1;
        if (bad == 1 || since == 0) since = now;
        sp.edit().putInt("bad", bad).putLong("bad_at", since).apply();
        if (bad >= 3 && now - since >= 20 * 60_000L) onSessionExpired(c);
    }

    private static String fetchToken(Context c, SharedPreferences sp, String aas, String email,
                                     String scope, String key) throws IOException {
        Map<String, String> f = base(c);
        f.put("Token", aas);
        f.put("Email", email);
        f.put("service", scope);
        f.put("app", YT_PKG);
        f.put("client_sig", YT_SIG);
        f.put("check_email", "1");
        f.put("has_permission", "1");
        f.put("token_request_options", "CAA4AVAB");
        f.put("system_partition", "1");
        f.put("_opt_is_called_from_account_manager", "1");
        Map<String, String> r = post(f);

        String tok = r.get("Auth");
        if (tok == null) {
            String err = String.valueOf(r.get("Error"));
            throw new AuthError(err, PERMANENT.contains(err));
        }
        long now = System.currentTimeMillis(), exp = now + 50 * 60_000L;
        try {
            if (r.get("Expiry") != null) exp = Long.parseLong(r.get("Expiry")) * 1000L;
            else if (r.get("ExpiresInDurationSec") != null) exp = now + Long.parseLong(r.get("ExpiresInDurationSec")) * 1000L;
        } catch (NumberFormatException ignored) {}
        if (exp < now + SKEW * 2) exp = now + 50 * 60_000L; // implausible value
        sp.edit().putString(key, tok).putLong(key + ":exp", exp).putInt("bad", 0).putLong("bad_at", 0).apply();
        return tok;
    }

    public static void clearToken(Context c, String token) {
        if (token == null) return;
        SharedPreferences sp = p(c);
        SharedPreferences.Editor e = sp.edit();
        for (Map.Entry<String, ?> en : sp.getAll().entrySet())
            if (en.getKey().startsWith("tok:") && token.equals(en.getValue()))
                e.putLong(en.getKey() + ":exp", 0);
        e.apply();
    }

    // ---- session ---------------------------------------------------------------------------

    static String getEmail(Context c) { return p(c).getString("email", null); }

    public static boolean isSignedIn(Context c) { return Vault.load(p(c), "aas") != null; }

    public static void signOut(Context c) { MiniGmsNotifyService.cancel(c); p(c).edit().clear().apply(); }

    /** Google revoked the credential: forget it so the app shows signed-out and login is offered again. */
    static void onSessionExpired(Context c) {
        Log.w(TAG, "session expired");
        signOut(c);
        MiniGmsNotifyService.notifyRelogin(c);
    }

    /** Exchange the EmbeddedSetup oauth_token cookie for a long-lived aas_et token. Returns the email. */
    static String completeLogin(Context c, String oauthToken) throws IOException {
        Map<String, String> f = base(c);
        f.put("Token", oauthToken);
        f.put("service", "ac2dm");
        f.put("add_account", "1");
        f.put("get_accountid", "1");
        f.put("ACCESS_TOKEN", "1");
        f.put("app", GMS_PKG);
        f.put("client_sig", GMS_SIG);
        f.put("callerPkg", GMS_PKG);
        f.put("callerSig", GMS_SIG);
        Map<String, String> r = post(f);
        String aas = r.get("Token"), email = r.get("Email");
        if (aas == null || email == null) throw new IOException("MiniGms: " + r.get("Error"));
        SharedPreferences sp = p(c);
        sp.edit().clear().apply();
        Vault.save(sp, "aas", aas);
        sp.edit().putString("email", email).apply();
        return email;
    }

    // ---- http ----------------------------------------------------------------------------

    private static Map<String, String> base(Context c) {
        String id = Settings.Secure.getString(c.getContentResolver(), Settings.Secure.ANDROID_ID);
        if (id == null || id.isEmpty()) id = "0123456789abcdef";
        Map<String, String> f = new LinkedHashMap<>();
        f.put("androidId", id);
        f.put("sdk_version", String.valueOf(android.os.Build.VERSION.SDK_INT));
        f.put("device_country", Locale.getDefault().getCountry().toLowerCase());
        f.put("lang", Locale.getDefault().toString());
        f.put("google_play_services_version", "244735038");
        return f;
    }

    private static Map<String, String> post(Map<String, String> form) throws IOException {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, String> e : form.entrySet()) {
            if (sb.length() > 0) sb.append('&');
            sb.append(URLEncoder.encode(e.getKey(), "UTF-8")).append('=')
              .append(URLEncoder.encode(e.getValue(), "UTF-8"));
        }
        byte[] body = sb.toString().getBytes("UTF-8");
        IOException first = null;
        // 1) our own TLS socket: does not touch the app's/system's default HTTPS stack that Google blocks.
        try {
            return parse(rawPost(body));
        } catch (IOException e) {
            first = e;
            CrashLog.record("login/token: raw TLS failed, trying HttpsURLConnection", e);
        }
        // 2) HttpsURLConnection, but with our own SSLContext instead of the default one.
        try {
            return parse(httpsPost(body));
        } catch (IOException e) {
            CrashLog.record("login/token: HttpsURLConnection failed too", e);
            throw first;
        }
    }

    private static javax.net.ssl.SSLSocketFactory ownFactory() throws IOException {
        try {
            javax.net.ssl.TrustManagerFactory tmf = javax.net.ssl.TrustManagerFactory
                    .getInstance(javax.net.ssl.TrustManagerFactory.getDefaultAlgorithm());
            tmf.init((java.security.KeyStore) null);
            javax.net.ssl.SSLContext ctx = javax.net.ssl.SSLContext.getInstance("TLSv1.2");
            ctx.init(null, tmf.getTrustManagers(), null);
            return ctx.getSocketFactory();
        } catch (Exception e) {
            throw new IOException("MiniGms: TLS setup failed: " + e);
        }
    }

    /** Minimal HTTP/1.1 POST over a plain SSLSocket. Returns the response body. */
    private static String rawPost(byte[] body) throws IOException {
        final String host = "android.googleapis.com";
        javax.net.ssl.SSLSocket sock = null;
        try {
            Socket plain = new Socket();
            plain.connect(new InetSocketAddress(host, 443), 15000);
            plain.setSoTimeout(15000);
            sock = (javax.net.ssl.SSLSocket) ownFactory().createSocket(plain, host, 443, true);
            sock.setEnabledProtocols(new String[]{"TLSv1.2"});
            sock.startHandshake();
            if (!javax.net.ssl.HttpsURLConnection.getDefaultHostnameVerifier().verify(host, sock.getSession()))
                throw new IOException("MiniGms: certificate does not match " + host);
            OutputStream o = sock.getOutputStream();
            String head = "POST /auth HTTP/1.1\r\nHost: " + host + "\r\n"
                    + "Content-Type: application/x-www-form-urlencoded\r\n"
                    + "User-Agent: GoogleAuth/1.4\r\nAccept-Encoding: identity\r\n"
                    + "Content-Length: " + body.length + "\r\nConnection: close\r\n\r\n";
            o.write(head.getBytes("ISO-8859-1"));
            o.write(body);
            o.flush();
            ByteArrayOutputStream all = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            InputStream in = sock.getInputStream();
            int n;
            while ((n = in.read(buf)) > 0) all.write(buf, 0, n);
            String raw = all.toString("ISO-8859-1");
            int split = raw.indexOf("\r\n\r\n");
            if (split < 0) throw new IOException("MiniGms: bad HTTP response");
            String hdr = raw.substring(0, split).toLowerCase(Locale.ROOT);
            String payload = raw.substring(split + 4);
            int code = 0;
            try { code = Integer.parseInt(hdr.split(" ")[1]); } catch (Exception ignored) {}
            if (hdr.contains("transfer-encoding: chunked")) payload = dechunk(payload);
            if (payload.trim().isEmpty() && code >= 400) throw new IOException("MiniGms: HTTP " + code);
            return new String(payload.getBytes("ISO-8859-1"), "UTF-8");
        } finally {
            if (sock != null) try { sock.close(); } catch (IOException ignored) {}
        }
    }

    private static String dechunk(String s) {
        StringBuilder out = new StringBuilder();
        int i = 0;
        while (i < s.length()) {
            int nl = s.indexOf("\r\n", i);
            if (nl < 0) break;
            int len;
            try { len = Integer.parseInt(s.substring(i, nl).split(";")[0].trim(), 16); } catch (Exception e) { break; }
            if (len == 0) break;
            out.append(s, nl + 2, Math.min(s.length(), nl + 2 + len));
            i = nl + 2 + len + 2;
        }
        return out.toString();
    }

    private static String httpsPost(byte[] body) throws IOException {
        javax.net.ssl.HttpsURLConnection h = (javax.net.ssl.HttpsURLConnection) new URL(AUTH_URL).openConnection();
        h.setSSLSocketFactory(ownFactory());
        h.setConnectTimeout(15000);
        h.setReadTimeout(15000);
        h.setRequestMethod("POST");
        h.setDoOutput(true);
        h.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
        h.setRequestProperty("User-Agent", "GoogleAuth/1.4");
        try (OutputStream o = h.getOutputStream()) { o.write(body); }
        int code = h.getResponseCode();
        InputStream in = code < 400 ? h.getInputStream() : h.getErrorStream();
        StringBuilder sb = new StringBuilder();
        if (in != null) try (BufferedReader br = new BufferedReader(new InputStreamReader(in, "UTF-8"))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line).append('\n');
        }
        if (sb.length() == 0 && code >= 400) throw new IOException("MiniGms: HTTP " + code);
        return sb.toString();
    }

    private static Map<String, String> parse(String text) {
        Map<String, String> out = new HashMap<>();
        for (String line : text.split("\r?\n")) {
            int i = line.indexOf('=');
            if (i > 0) out.put(line.substring(0, i), line.substring(i + 1));
        }
        return out;
    }
}
