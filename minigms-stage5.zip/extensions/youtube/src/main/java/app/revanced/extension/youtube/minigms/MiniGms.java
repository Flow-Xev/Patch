package app.revanced.extension.youtube.minigms;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;

import java.io.*;
import java.net.*;
import java.util.*;

/** Tiny stand-in for the parts of microG that YouTube needs: account + OAuth tokens. */
public final class MiniGms {
    static final String TAG = "MiniGms";
    static final String GOOGLE = "com.google";
    private static final String AUTH_URL = "https://android.googleapis.com/auth";
    private static final String GMS_PKG = "com.google.android.gms";
    private static final String GMS_SIG = "38918a453d07199354f8b19af05ec6562ced5788";
    private static final String YT_PKG = "com.google.android.youtube";
    private static final String YT_SIG = "24bb24c05e47e0aefa68a58a766179d9b613a600";
    private static final int MAX_LOGIN_PROMPTS = 3;
    private static final long DAY = 24L * 3600 * 1000, SKEW = 2L * 60 * 1000;
    private static final Set<String> PERMANENT = new HashSet<>(Arrays.asList(
            "BadAuthentication", "AccountDeleted", "AccountDisabled", "InvalidSecondFactor", "NeedsBrowser"));
    static final String YT_SCOPE = "oauth2:https://www.googleapis.com/auth/youtube";
    private static final java.util.concurrent.ConcurrentHashMap<String, Object> LOCKS =
            new java.util.concurrent.ConcurrentHashMap<>();

    /** Token request failed; permanent = Google says the stored credential is no longer valid. */
    static final class AuthError extends IOException {
        final boolean permanent;
        AuthError(String m, boolean permanent) { super("MiniGms: " + m); this.permanent = permanent; }
    }

    static SharedPreferences p(Context c) { return c.getSharedPreferences("minigms", Context.MODE_PRIVATE); }

    static Context appContext() {
        try {
            return (Context) Class.forName("android.app.ActivityThread")
                    .getMethod("currentApplication").invoke(null);
        } catch (Exception e) { throw new IllegalStateException(e); }
    }

    // ---- hooks called from patched app code ----------------------------------------------

    /** Main activity onCreate: ask to sign in (first launch, then at most once a day, 3 times). */
    public static void onAppStart(Activity a) {
        if (isSignedIn(a)) { MiniGmsNotifyService.schedule(a); askNotifPermission(a); return; }
        SharedPreferences sp = p(a);
        int n = sp.getInt("asks", 0);
        long now = System.currentTimeMillis();
        if (n >= MAX_LOGIN_PROMPTS || (n > 0 && now - sp.getLong("ask_at", 0) < DAY)) return;
        sp.edit().putInt("asks", n + 1).putLong("ask_at", now).apply();
        a.startActivity(new Intent(a, MiniGmsLoginActivity.class));
    }

    /** Android 13+: ask for the notification permission once. */
    private static void askNotifPermission(Activity a) {
        String perm = "android.permission.POST_NOTIFICATIONS";
        SharedPreferences sp = p(a);
        if (android.os.Build.VERSION.SDK_INT < 33 || sp.getBoolean("notif_asked", false)
                || a.checkSelfPermission(perm) == android.content.pm.PackageManager.PERMISSION_GRANTED) return;
        sp.edit().putBoolean("notif_asked", true).apply();
        a.requestPermissions(new String[]{perm}, 7311);
    }

    public static int gmsAvailable(Object api, Context c) { return 0; }
    public static int gmsAvailableStatic(Context c) { return 0; }
    public static int gmsAvailableMin(Object api, Context c, int min) { return 0; }

    public static Account[] getAccounts(AccountManager am, String type) {
        if (!GOOGLE.equals(type)) return am.getAccountsByType(type);
        String email = getEmail(appContext());
        return email == null ? new Account[0] : new Account[]{new Account(email, GOOGLE)};
    }

    public static Account[] getAllAccounts(AccountManager am) {
        List<Account> l = new ArrayList<>();
        try { l.addAll(Arrays.asList(am.getAccounts())); } catch (Throwable ignored) {}
        String email = getEmail(appContext());
        if (email != null) {
            Account a = new Account(email, GOOGLE);
            if (!l.contains(a)) l.add(0, a);
        }
        return l.toArray(new Account[0]);
    }

    public static String blockingGetAuthToken(AccountManager am, Account a, String type, boolean notify)
            throws IOException {
        return getTokenByName(appContext(), a.name, type);
    }

    public static void invalidateAuthToken(AccountManager am, String type, String token) {
        if (GOOGLE.equals(type)) clearToken(appContext(), token);
        else am.invalidateAuthToken(type, token);
    }

    public static String getToken(Context c, Account acc, String scope) throws IOException {
        return getTokenByName(c, acc.name, scope);
    }

    public static String getToken(Context c, Account acc, String scope, Bundle extras) throws IOException {
        return getTokenByName(c, acc.name, scope);
    }

    /** Cached access token, renewed ~2 min before expiry; retries transient failures. */
    public static String getTokenByName(Context c, String email, String scope) throws IOException {
        return token(c, email, scope, false);
    }

    /** Force a new access token for the YouTube scope (used by settings + background job). */
    static void renew(Context c) throws IOException {
        String email = getEmail(c);
        if (email == null) throw new IOException("MiniGms: not signed in");
        token(c, email, YT_SCOPE, true);
    }

    /** Refresh every cached token that expires within {@code window} ms, so the app never meets an expired one. */
    static void renewExpiring(Context c, long window) {
        SharedPreferences sp = p(c);
        String email = getEmail(c);
        if (email == null) return;
        for (String k : new ArrayList<>(sp.getAll().keySet())) {
            if (!k.startsWith("tok:") || k.endsWith(":exp")) continue;
            if (sp.getLong(k + ":exp", 0) - System.currentTimeMillis() < window) {
                try { token(c, email, k.substring(4), true); } catch (IOException ignored) {}
            }
        }
    }

    private static String token(Context c, String email, String scope, boolean force) throws IOException {
        SharedPreferences sp = p(c);
        String aas = Vault.load(sp, "aas");
        if (aas == null) throw new IOException("MiniGms: not signed in");
        if (!scope.startsWith("oauth2:") && !scope.startsWith("audience:")) scope = "oauth2:" + scope;
        String key = "tok:" + scope;
        Object lock = LOCKS.computeIfAbsent(key, k -> new Object()); // one refresh per scope, others reuse it
        synchronized (lock) {
            String cached = sp.getString(key, null);
            if (!force && cached != null && System.currentTimeMillis() < sp.getLong(key + ":exp", 0) - SKEW)
                return cached;
            IOException last = null;
            for (int i = 0; i < 3; i++) {
                try {
                    return fetchToken(c, sp, aas, email, scope, key);
                } catch (AuthError e) {
                    if (e.permanent) { rejected(c, sp); throw e; }
                    last = e;
                } catch (IOException e) {
                    last = e;
                }
                if (i < 2) try { Thread.sleep(1000L * (i + 1)); } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
            throw last != null ? last : new IOException("MiniGms: interrupted");
        }
    }

    /** Google rejected the stored credential. Sign out only if it keeps happening for 20+ min (not a blip). */
    private static void rejected(Context c, SharedPreferences sp) {
        long now = System.currentTimeMillis(), since = sp.getLong("bad_at", 0);
        int bad = sp.getInt("bad", 0) + 1;
        if (bad == 1 || since == 0) since = now;
        sp.edit().putInt("bad", bad).putLong("bad_at", since).apply();
        if (bad >= 3 && now - since >= 20 * 60_000L) onSessionExpired(c);
    }

    private static String fetchToken(Context c, SharedPreferences sp, String aas, String email,
                                     String scope, String key) throws IOException {
        Map<String, String> f = base(c);
        f.put("Token", aas);
        f.put("Email", email);
        f.put("service", scope);
        f.put("app", YT_PKG);
        f.put("client_sig", YT_SIG);
        f.put("check_email", "1");
        f.put("has_permission", "1");
        f.put("token_request_options", "CAA4AVAB");
        f.put("system_partition", "1");
        f.put("_opt_is_called_from_account_manager", "1");
        Map<String, String> r = post(f);

        String tok = r.get("Auth");
        if (tok == null) {
            String err = String.valueOf(r.get("Error"));
            throw new AuthError(err, PERMANENT.contains(err));
        }
        long now = System.currentTimeMillis(), exp = now + 50 * 60_000L;
        try {
            if (r.get("Expiry") != null) exp = Long.parseLong(r.get("Expiry")) * 1000L;
            else if (r.get("ExpiresInDurationSec") != null) exp = now + Long.parseLong(r.get("ExpiresInDurationSec")) * 1000L;
        } catch (NumberFormatException ignored) {}
        if (exp < now + SKEW * 2) exp = now + 50 * 60_000L; // implausible value
        sp.edit().putString(key, tok).putLong(key + ":exp", exp).putInt("bad", 0).putLong("bad_at", 0).apply();
        return tok;
    }

    public static void clearToken(Context c, String token) {
        if (token == null) return;
        SharedPreferences sp = p(c);
        SharedPreferences.Editor e = sp.edit();
        for (Map.Entry<String, ?> en : sp.getAll().entrySet())
            if (en.getKey().startsWith("tok:") && token.equals(en.getValue()))
                e.putLong(en.getKey() + ":exp", 0);
        e.apply();
    }

    // ---- session ---------------------------------------------------------------------------

    static String getEmail(Context c) { return p(c).getString("email", null); }

    public static boolean isSignedIn(Context c) { return Vault.load(p(c), "aas") != null; }

    public static void signOut(Context c) { MiniGmsNotifyService.cancel(c); p(c).edit().clear().apply(); }

    /** Google revoked the credential: forget it so the app shows signed-out and login is offered again. */
    static void onSessionExpired(Context c) {
        Log.w(TAG, "session expired");
        signOut(c);
        MiniGmsNotifyService.notifyRelogin(c);
    }

    /** Exchange the EmbeddedSetup oauth_token cookie for a long-lived aas_et token. Returns the email. */
    static String completeLogin(Context c, String oauthToken) throws IOException {
        Map<String, String> f = base(c);
        f.put("Token", oauthToken);
        f.put("service", "ac2dm");
        f.put("add_account", "1");
        f.put("get_accountid", "1");
        f.put("ACCESS_TOKEN", "1");
        f.put("app", GMS_PKG);
        f.put("client_sig", GMS_SIG);
        f.put("callerPkg", GMS_PKG);
        f.put("callerSig", GMS_SIG);
        Map<String, String> r = post(f);
        String aas = r.get("Token"), email = r.get("Email");
        if (aas == null || email == null) throw new IOException("MiniGms: " + r.get("Error"));
        SharedPreferences sp = p(c);
        sp.edit().clear().apply();
        Vault.save(sp, "aas", aas);
        sp.edit().putString("email", email).apply();
        return email;
    }

    // ---- http ----------------------------------------------------------------------------

    private static Map<String, String> base(Context c) {
        String id = Settings.Secure.getString(c.getContentResolver(), Settings.Secure.ANDROID_ID);
        if (id == null || id.isEmpty()) id = "0123456789abcdef";
        Map<String, String> f = new LinkedHashMap<>();
        f.put("androidId", id);
        f.put("sdk_version", String.valueOf(android.os.Build.VERSION.SDK_INT));
        f.put("device_country", Locale.getDefault().getCountry().toLowerCase());
        f.put("lang", Locale.getDefault().toString());
        f.put("google_play_services_version", "244735038");
        return f;
    }

    private static Map<String, String> post(Map<String, String> form) throws IOException {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, String> e : form.entrySet()) {
            if (sb.length() > 0) sb.append('&');
            sb.append(URLEncoder.encode(e.getKey(), "UTF-8")).append('=')
              .append(URLEncoder.encode(e.getValue(), "UTF-8"));
        }
        HttpURLConnection h = (HttpURLConnection) new URL(AUTH_URL).openConnection();
        h.setConnectTimeout(15000);
        h.setReadTimeout(15000);
        h.setRequestMethod("POST");
        h.setDoOutput(true);
        h.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
        h.setRequestProperty("User-Agent", "GoogleAuth/1.4");
        try (OutputStream o = h.getOutputStream()) { o.write(sb.toString().getBytes("UTF-8")); }
        int code = h.getResponseCode();
        InputStream in = code < 400 ? h.getInputStream() : h.getErrorStream();
        Map<String, String> out = new HashMap<>();
        if (in != null) {
            try (BufferedReader br = new BufferedReader(new InputStreamReader(in))) {
                String line;
                while ((line = br.readLine()) != null) {
                    int i = line.indexOf('=');
                    if (i > 0) out.put(line.substring(0, i), line.substring(i + 1));
                }
            }
        }
        if (out.isEmpty() && code >= 500) throw new IOException("MiniGms: HTTP " + code);
        return out;
    }
}
